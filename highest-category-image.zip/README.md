# highest-category-image
Plugin to display the category image of the highest-level category next to the post-title.
